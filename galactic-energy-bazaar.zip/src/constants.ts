const CONSTANTS = {
    API_VERSION: 'v1'
} as const;

export default CONSTANTS;